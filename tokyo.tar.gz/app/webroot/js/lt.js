$(document).ready(function() {
	 $(window).scroll(function () {
		
		if ($(window).scrollTop() > 80) {
		  $('.nav-top').addClass('navbar-fixed-top').removeClass('drop');
		}
		if ($(window).scrollTop() < 81) {
		  $('.nav-top').removeClass('navbar-fixed-top');
		  $('.nav-top').addClass('drop');
		}
	});
   
	// get current URL path and assign 'active' class
	var pathname = window.location.pathname;
	$('.nav > li > a[href="'+pathname+'"]').parent().addClass('active');
	$(function(){
		$('#menuJpg').booklet({
			closed: true, 
			width: '100%',
			height:800,
			pagePadding : 0
		});
	

		// var closed = $("#menuJpg").booklet( "option", "closed" );
		// var height = $("#menuJpg").booklet( "option", "height" );
		// $("#menuJpg").booklet( "option", "closed", true );
		// $("#menuJpg").booklet( "option", "height", 900 );
	});
	$('#specials').click(function (e) {
  		e.preventDefault()
  		$(this).tab('show')
  		$(this).addClass('active')
	})
	$('#events').click(function (e) {
  		e.preventDefault()
  		$(this).tab('show')
  		$(this).parent(addClass('active'))
	})
	$('#reviews').click(function (e) {
  		e.preventDefault()
  		$(this).tab('show')
  		$(this).addClass('active')
	})


	// function initialize() {

     

    
 //    google.maps.event.addDomListener(window, 'load', initialize);
 //    var map = new google.maps.Map(document.getElementById('lt-map'),
 //        mapOptions);
    
 //    var marker, i;

 //    for (i = 0; i < locations.length; i++) {  
 //      	marker = new google.maps.Marker({
 //        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
 //        map: map
 //      });
 //  	}

 //    var infowindow = new google.maps.InfoWindow();

 //      google.maps.event.addListener(marker, 'click', (function(marker, i) {
 //        return function() {
 //          infowindow.setContent(locations[i][0]);
 //          infowindow.open(map, marker);
 //        }
 //      })(marker, i));  
  	
 //  }

    var locations =[ 
    	['Little Tokyo on Leonard Ave.','35.341055','-80.177853', 2],
    	['Tokyo Lounge', '35.373430', '-80.195943', 1] 
	];
	var mapOptions = {
  		center: { lat: 35.3519883, lng: -80.1901338},
  		zoom: 14,
  		scrollwheel: false
    };

    var map = new google.maps.Map(document.getElementById('lt-map'), mapOptions);
    

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
});